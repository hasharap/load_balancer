/*
 *
 *
 *
 *
 * mcp3912Lib.c
 *
 * Library for interfacing with the MCP3912 3V Four-Channel Analog Front end
 * Author:      Vega Innovations (Pvt) Ltd
 * Date:        29/05/2024
 * Description: This library provides functions to communicate with and control the MCP3912 Four Channel AFE.
 * Notes:       The function dataExchangeMCP3912 has been tailored to accommodate the microcontroller utilized in
 *              the implementation.
 *
 *
 *
 */

#include "mcp3912Lib.h"
#include "math.h"
#include "stdbool.h"
#include "main.h"
#include "stdlib.h"

extern SPI_HandleTypeDef hspi1;
extern TIM_HandleTypeDef htim2;


// Fixed TX buffer — only set once
uint8_t spi_tx_buf[SPI_TX_SIZE] = {
    0x41, // command byte
    0x00, 0x00, 0x00, // for voltage
    0x00, 0x00, 0x00, // for current1
    0x00, 0x00, 0x00, // for current2
    0x00, 0x00, 0x00  // for current3
};

int8_t spi_rx_buf[SPI_RX_SIZE];


const float Vslop=0.014204;
const float Islop= 0.00140;

float previousSample=0;
bool execute=false;


float VsqrdTotal=0;
float I1sqrdTotal=0;
float I2sqrdTotal=0;
float I3sqrdTotal=0;



static float VoltA[SAMPLE_SIZE];
float VoltB[SAMPLE_SIZE];
static float VoltLagA[SAMPLE_SIZE];
float VoltLagB[SAMPLE_SIZE];
static float VoltLeadA[SAMPLE_SIZE];
float VoltLeadB[SAMPLE_SIZE];



static float I1A[SAMPLE_SIZE];
float I1B[SAMPLE_SIZE];
static float I2A[SAMPLE_SIZE];
float I2B[SAMPLE_SIZE];
static float I3A[SAMPLE_SIZE];
float I3B[SAMPLE_SIZE];

//float previousSample=0;
//bool  execute = false;

//Pointers for  Double Buffering
static float* writeVolt       = VoltA;
static float* readVolt        = VoltB;
static float* writeVoltLag    = VoltLagA;
static float* readVoltLag     = VoltLagB;
static float* writeVoltLead   = VoltLeadA;
static float* readVoltLead    = VoltLeadB;


static float* writeI1         = I1A;
static float* readI1          = I1B;
static float* writeI2         = I2A;
static float* readI2          = I2B;
static float* writeI3         = I3A;
static float* readI3          = I3B;


volatile struct PhaseDataStruct PhaseData;
volatile struct Signs  mark;


LoadBalancer_t LB_type = NotApper;


float Vrms=220;  //   assume Vrms is 220 in the begining
float I1rms=0;
float I2rms=0;
float I3rms=0;



volatile uint16_t bufferIndex=0;


const float SQRT2 = 1.41421356237;
const float PI    =  3.1415;




int16_t n1=0;
float ratio=0;


float powerSum=0;
float powerSumLag=0;
float powerSumLead=0;


void mcp3912begin()
{

    HAL_GPIO_WritePin(ADC_RST_GPIO_Port,ADC_RST_Pin, GPIO_PIN_SET); 	//pull up the reset pin
 	TIM2->CCR2 = (uint32_t)4;
	HAL_TIM_PWM_Start(&htim2, TIM_CHANNEL_2);

	PhaseData.Vrms=210;
	PhaseData.I1rms =0;
	PhaseData.I2rms =0;
	PhaseData.I3rms =0;

	mark.i1s =1; // initialize directions as one for rms
	mark.i2s =1;
	mark.i3s =1;


}


bool isZeroCross(float a, float b)
 {
    return (a < 0 && b >= 0) || (a > 0 && b <= 0);
 }


int findNearestZeroCross(float *buffer, int center, int range, int maxSize) {
    for (int offset = 0; offset <= range; offset++) {
        // Check forward
        int idxF = center + offset;
        if (idxF + 1 < maxSize && isZeroCross(buffer[idxF], buffer[idxF + 1])) {
            return idxF;
        }

        // Check backward
        int idxB = center - offset;
        if (idxB - 1 >= 0 && isZeroCross(buffer[idxB - 1], buffer[idxB])) {
            return idxB - 1;
        }
    }
    return -1;
}

// Main function to find and confirm matching phase
PhaseType  findMatchingPhase(float *i, float *v1, float *v2, float *v3, uint16_t size) {

	PhaseType currentMatch = PHASE_NONE;
    // 1. Find Current zero-crossing
    int currentZeroIdx = findNearestZeroCross(i, 80, 50,500);
    if (currentZeroIdx == -1) return currentMatch;  // No change

    // 2. Check for zero-cross in each voltage buffer near current zero
    int v1ZeroIdx = findNearestZeroCross(v1, currentZeroIdx,20,400);
    int v2ZeroIdx = findNearestZeroCross(v2, currentZeroIdx,20,400);
    int v3ZeroIdx = findNearestZeroCross(v3, currentZeroIdx,20,400);

    // 3. Calculate distances to voltage zero-cross
    int d1 = (v1ZeroIdx >= 0) ? abs(v1ZeroIdx - currentZeroIdx) : SAMPLE_RATE;
    int d2 = (v2ZeroIdx >= 0) ? abs(v2ZeroIdx - currentZeroIdx) : SAMPLE_RATE;
    int d3 = (v3ZeroIdx >= 0) ? abs(v3ZeroIdx - currentZeroIdx) : SAMPLE_RATE;

    // 4. Find best match


    if (d1 <= d2 && d1 <= d3) currentMatch = PHASE_MATCH;
    else if (d2 <= d1 && d2 <= d3) currentMatch = PHASE_LAG;
    else if (d3 <= d1 && d3 <= d2) currentMatch = PHASE_LEAD;



    return currentMatch;
}


void SwapToProcess(void)
{
	bufferIndex=0;
	execute=false;
	previousSample=0;


	PhaseData.Vrms   =  sqrt(VsqrdTotal/SAMPLE_SIZE);
	PhaseData.I1rms  = (mark.i1s)*sqrt(I1sqrdTotal/SAMPLE_SIZE);
	PhaseData.I2rms  = (mark.i2s)*sqrt(I2sqrdTotal/SAMPLE_SIZE);
	PhaseData.I3rms  = (mark.i3s)*sqrt(I3sqrdTotal/SAMPLE_SIZE);


    //Double Buffering
	 float* temp = writeVolt;
	 writeVolt = readVolt;
	 readVolt = temp;

	 temp = writeVoltLag;
	 writeVoltLag = readVoltLag;
	 readVoltLag = temp;

	 temp = writeVoltLead;
	 writeVoltLead = readVoltLead;
	 readVoltLead = temp;


	 temp =writeI1;
	 writeI1=readI1;
	 readI1=temp;

	 temp =writeI2;
	 writeI2=readI2;
	 readI2=temp;

	 temp =writeI3;
	 writeI3=readI3;
	 readI3=temp;


	VsqrdTotal=0;
	I1sqrdTotal=0;
	I2sqrdTotal=0;
	I3sqrdTotal=0;


}



void readChannels()
{
	 HAL_GPIO_WritePin(GPIOA, GPIO_PIN_4, GPIO_PIN_RESET);
	 HAL_SPI_TransmitReceive(&hspi1, spi_tx_buf, spi_rx_buf, SPI_TX_SIZE, HAL_MAX_DELAY);
	 HAL_GPIO_WritePin(GPIOA, GPIO_PIN_4, GPIO_PIN_SET);

	float VoltageSample = ((spi_rx_buf[1] << 8) | (spi_rx_buf[2] & 0xff)) * Vslop;


	if(!execute)
	{
		if(previousSample<0 && VoltageSample>0)
		{
			execute=true;

		}
		else
		{
			previousSample=VoltageSample;
			return;
		}


	}

	float CurrentSample1 = ((spi_rx_buf[4] << 8) | (spi_rx_buf[5] & 0xff)) * Islop;
	float CurrentSample2 = ((spi_rx_buf[7] << 8) | (spi_rx_buf[8] & 0xff)) * Islop;
	float CurrentSample3 = ((spi_rx_buf[10] << 8) | (spi_rx_buf[11] & 0xff)) * Islop;

	VsqrdTotal += (VoltageSample*VoltageSample);
	writeVolt[bufferIndex]=VoltageSample;
    writeVoltLag[bufferIndex]=(PhaseData.Vrms*SQRT2)*sin(((2*PI*bufferIndex)/SAMPLE_RATE)-(2*PI/3));
    writeVoltLead[bufferIndex]=(PhaseData.Vrms*SQRT2)*sin(((2*PI*bufferIndex)/SAMPLE_RATE)+(2*PI/3));

	I1sqrdTotal += (CurrentSample1*CurrentSample1);
    writeI1[bufferIndex]=CurrentSample1;

	I2sqrdTotal += (CurrentSample2*CurrentSample2);
	writeI2[bufferIndex]=CurrentSample2;

	I3sqrdTotal += (CurrentSample3*CurrentSample3);
	writeI3[bufferIndex]=CurrentSample3;

	bufferIndex++;

}

LoadBalancer_t DetectLBType(struct PhaseDataStruct data , float threshold)
{
	if (data.I1rms > threshold && data.I2rms > threshold && data.I3rms > threshold)
	        return Tp;
	    else if (data.I1rms > threshold)
	        return Sp1;
	    else if (data.I2rms > threshold)
	        return Sp2;
	    else if (data.I3rms > threshold)
	        return Sp3;
	    else
	        return NotApper;

}


PowerDirection calculateDirection(float *i, float *v, uint16_t size) {
    float sum = 0;
    for (uint16_t j = 0; j < size; j++) {
        sum += v[j] * i[j];  // instantaneous power
    }

    float avgPower = sum ;// size;

    if (avgPower > 0.01f) return POWER_FORWARD;
    else if (avgPower < -0.01f) return POWER_REVERSE;
    else return POWER_UNKNOWN;
}



float* getVoltageBuffer(PhaseType phase) {
    switch (phase) {
        case PHASE_MATCH: return VoltB;
        case PHASE_LAG: return VoltLagB;
        case PHASE_LEAD: return VoltLeadB;
        default: return NULL;
    }
}


void updateMark(uint8_t readingNumber, PowerDirection currentDir, PowerDirection defaultDir) {
    int8_t value = (currentDir == defaultDir) ? +1 : -1;

    switch (readingNumber) {
        case 1: mark.i1s = value; break;
        case 2: mark.i2s = value; break;
        case 3: mark.i3s = value; break;
        default: break;
    }
}



bool directionsConfirm(Directions d1, Directions d2) {
    return (d1.ofcurrentRead_1 == d2.ofcurrentRead_1) &&
           (d1.ofcurrentRead_2 == d2.ofcurrentRead_2) &&
           (d1.ofcurrentRead_3 == d2.ofcurrentRead_3);
}


bool PhasesConfirm(PhaseRelation p1, PhaseRelation p2) {
    return (p1.currentRead_1 == p2.currentRead_1) &&
           (p1.currentRead_2 == p2.currentRead_2) &&
           (p1.currentRead_3 == p2.currentRead_3);
}

